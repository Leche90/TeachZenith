import type { NormalizedJob, TargetMarket } from "./types.js";
import { RESULTS_PER_QUERY } from "./markets.js";

// JSearch via OpenWeb Ninja direct portal (preferred — avoids RapidAPI transfer limits).
// If you signed up through RapidAPI instead, set JSEARCH_HOST to the RapidAPI host
// and the code will send the RapidAPI headers instead.
const API_KEY = process.env.JSEARCH_API_KEY;
const HOST = process.env.JSEARCH_HOST || "api.openwebninja.com"; // direct portal default

// JSearch search endpoint returns data[] with ~40 fields. We use:
//   job_title, employer_name, job_city/job_country, job_apply_link,
//   job_posted_at_datetime_utc (ISO) or job_posted_at_timestamp (unix seconds),
//   job_description
interface JSearchResult {
  job_title?: string;
  employer_name?: string;
  job_city?: string;
  job_country?: string;
  job_apply_link?: string;
  job_posted_at_datetime_utc?: string;
  job_posted_at_timestamp?: number;
  job_description?: string;
}
interface JSearchResponse {
  status?: string;
  data?: JSearchResult[];
}

export async function fetchJSearch(market: TargetMarket): Promise<NormalizedJob[]> {
  if (!API_KEY) {
    console.warn("  [jsearch] missing JSEARCH_API_KEY — skipping");
    return [];
  }

  const usingRapidApi = HOST.includes("rapidapi.com");
  const headers: Record<string, string> = usingRapidApi
    ? { "x-rapidapi-key": API_KEY, "x-rapidapi-host": HOST }
    : { "x-api-key": API_KEY };

  const jobs: NormalizedJob[] = [];
  for (const query of market.queries) {
    // date_posted=month keeps results recent at the source; we still apply our own
    // 14-day freshness filter downstream for a true picture.
    // Endpoint: current JSearch is /jsearch/search-v2 on the OpenWeb Ninja portal.
    const base = HOST.includes("rapidapi.com")
      ? `https://${HOST}/search`
      : `https://${HOST}/jsearch/search-v2`;
    const url =
      `${base}` +
      `?query=${encodeURIComponent(query)}` +
      `&country=${encodeURIComponent(market.jsearchCountry)}` +
      `&date_posted=month` +
      `&num_pages=1`;

    try {
      const res = await fetch(url, { headers });
      if (!res.ok) {
        console.warn(`  [jsearch] ${market.label} "${query}" -> HTTP ${res.status}`);
        continue;
      }
      const data = (await res.json()) as JSearchResponse;
      const rows = (data.data ?? []).slice(0, RESULTS_PER_QUERY);
      for (const r of rows) {
        let posted: Date | null = null;
        if (r.job_posted_at_datetime_utc) posted = new Date(r.job_posted_at_datetime_utc);
        else if (r.job_posted_at_timestamp) posted = new Date(r.job_posted_at_timestamp * 1000);

        const loc = [r.job_city, r.job_country].filter(Boolean).join(", ") || null;
        jobs.push({
          source: "jsearch",
          title: r.job_title ?? "(no title)",
          company: r.employer_name ?? null,
          location: loc,
          country: market.label,
          datePosted: posted,
          url: r.job_apply_link ?? null,
          descriptionSnippet: (r.job_description ?? "").slice(0, 160) || null,
        });
      }
    } catch (err) {
      console.warn(`  [jsearch] ${market.label} "${query}" -> error: ${(err as Error).message}`);
    }
    await sleep(1200); // JSearch free tier is rate-limited; go gently
  }
  return jobs;
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
