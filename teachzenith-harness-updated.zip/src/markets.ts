import type { TargetMarket } from "./types.js";

// IMPORTANT REALITY CHECK (worth verifying when you run this):
// - Adzuna supports a FIXED set of countries: gb, us, ca, au, de, fr, nl, it,
//   es, pl, br, in, sg, za, mx, at, nz, ch, be. It does NOT cover UAE, Qatar,
//   Saudi, or most of your priority Gulf markets. So for the Gulf, Adzuna will
//   simply have no endpoint — we expect zeros there and that's a finding, not a bug.
// - JSearch pulls from Google for Jobs and IS global, so it's our real test for
//   the Gulf/Asia roles that matter most for TeachZenith.
//
// The harness queries each API only where it plausibly has coverage, so the
// report reflects each source's true reach rather than punishing Adzuna for
// markets it never claimed to serve.

export const TARGET_MARKETS: TargetMarket[] = [
  {
    label: "UAE (Dubai/Abu Dhabi)",
    adzunaCountry: "",        // not supported by Adzuna
    jsearchCountry: "ae",
    queries: ["international school teacher"],
  },
  {
    label: "Qatar",
    adzunaCountry: "",
    jsearchCountry: "qa",
    queries: ["international school teacher"],
  },
  {
    label: "Saudi Arabia",
    adzunaCountry: "",
    jsearchCountry: "sa",
    queries: ["international school teacher"],
  },
  {
    label: "Singapore",
    adzunaCountry: "sg",      // Adzuna DOES cover Singapore
    jsearchCountry: "sg",
    queries: ["international school teacher"],
  },
  {
    label: "UK (flagship/gap-analysis market)",
    adzunaCountry: "gb",
    jsearchCountry: "gb",
    queries: ["physics teacher"],
  },
];

// Freshness ceiling from your spec: only roles seen within this many days count as "fresh".
export const FRESHNESS_DAYS = 14;

// Keep result volume modest during testing so we don't burn free-tier quota.
export const RESULTS_PER_QUERY = 20;
